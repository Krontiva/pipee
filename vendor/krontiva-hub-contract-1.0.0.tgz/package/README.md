# @krontiva/hub-contract

Shared types and helpers for the [Krontiva Hub Integration Contract v1](https://hub.krontiva.africa).

Zero runtime dependencies. Web Crypto only, so the same build runs on Node 18+,
Deno, and Edge runtimes — which matters because the three integrating products
span all three.

## Why this exists

Contract §9: *"Four repos with a hand-copied schema will drift within a month."*

Two pieces in particular will diverge if each product writes its own:

- **Capability implication.** §2.3 asks products to resolve `admin → write → read`
  locally. Three implementations of that rule become three subtly different
  permission models.
- **Request signing.** The HMAC has three easy-to-miss details: the timestamp is
  in *seconds*, the separator is a literal `.`, and you must sign the exact
  string you send. Serialising twice can reorder keys and invalidate the
  signature.

## Install

Not yet on a registry. Until one exists, either:

```bash
# From a local checkout of the Hub repo
npm install ../Hub/packages/hub-contract

# Or pack a tarball and commit it
cd Hub/packages/hub-contract && npm pack
npm install ../krontiva-hub-contract-1.0.0.tgz
```

## Verifying a session

```ts
import { SESSION_COOKIE, HUB_ENDPOINTS, type HubClaims, type RequestContext } from '@krontiva/hub-contract'
import { jwtVerify, createRemoteJWKSet } from 'jose'

// Module scope — the JWKS is cached and respects Hub's cache headers.
const jwks = createRemoteJWKSet(new URL(HUB_ENDPOINTS.jwks))

export async function contextFrom(req: Request): Promise<RequestContext | null> {
  const token = getCookie(req, SESSION_COOKIE)
  if (!token) return null

  try {
    const { payload } = await jwtVerify<HubClaims>(token, jwks, { issuer: 'https://hub.krontiva.africa' })
    return { userId: payload.sub, email: payload.email, caps: payload.caps }
  } catch {
    return null
  }
}
```

## Authorizing

Authorize on `caps`, never on `role` — role-to-capability mapping is Hub's
business and changes without a deploy.

```ts
import { requireCap, isProductAdmin, CapabilityDeniedError, buildCapabilityDeniedEvent } from '@krontiva/hub-contract'

try {
  requireCap(ctx, 'pipee:write')
} catch (e) {
  if (e instanceof CapabilityDeniedError) {
    // §2.4 — a denial is a product signal, not just an error.
    await outbox.write(buildCapabilityDeniedEvent('pipee', ctx, e.capability))
    return new Response('Forbidden', { status: 403 })
  }
  throw e
}

// Owner scoping, made explicit rather than left to a row-level policy.
const q = db.from('opportunities').select()
if (!isProductAdmin(ctx, 'pipee')) q.eq('assigned_to', ctx.userId)
```

## Pushing data

Never POST to Hub inline in a request handler (§3.3). Write to a local outbox in
the same transaction as the domain write, and let a worker drain it — then a Hub
outage costs freshness, not data.

```ts
import { HubClient, partitionWorkItems } from '@krontiva/hub-contract'

const hub = new HubClient({ productId: 'pipee', secret: process.env.PIPEE_HUB_SECRET! })

// In your drain worker, every 60s:
const rows = await db.query('select * from hub_outbox where delivered_at is null order by id limit 100')

const { valid, invalid } = partitionWorkItems(rows.map(r => r.payload))
if (invalid.length) {
  // Log what was dropped — a silent truncation reads as "everything synced".
  console.warn('[outbox] unsendable rows', invalid)
}

const result = await hub.sendWorkItems(valid)
if (result.ok) {
  await markDelivered(rows)
} else if (result.retryable) {
  await backoff(rows, result.error)      // network, 429, or 5xx
} else {
  await markPoisoned(rows, result.error) // 400 or 401 — needs a fix, not a retry
}
```

`HubClient` deliberately does not retry. Backoff state belongs in your worker;
this only tells you whether retrying is worth it.

## Validating before you send

Hub returns `400` for a malformed payload, which is unhelpful from inside a
worker — the row is not retryable, so it sits there failing quietly. Validate at
the emit site instead, where the error lands next to the code that built it.

```ts
import { assertWorkItem, ContractViolationError } from '@krontiva/hub-contract'

try {
  assertWorkItem(item)
} catch (e) {
  if (e instanceof ContractViolationError) {
    console.error(`Cannot send ${item.external_id}: ${e.field} — ${e.message}`)
  }
}
```

Catches the three fields Hub is strict about — non-null `owner_id`, a valid
`state`, a present `url` — plus `blocked_since` consistency, which otherwise
makes the blocked-and-aging section quietly wrong rather than visibly broken.

## Heartbeat

Every 15 minutes. Hub compares your counts against its own and alerts on drift,
because a worker delivering half its events is more dangerous than one
delivering none (§5).

```ts
await hub.sendHeartbeat({
  sent_at: new Date().toISOString(),
  work_item_counts: { open: 12, active: 5, blocked: 2, done: 88 },
  outbox_pending: await countPending(),
  outbox_oldest_pending_seconds: await oldestPendingAge(),
})
```

## Exports

| Module | Contents |
|---|---|
| `constants` | Endpoints, cookie name, header names, states, horizons, reserved actions, limits |
| `types` | `HubClaims`, `RequestContext`, `HubEvent`, `HubWorkItem`, `HubHeartbeat`, `OutboxRow`, `DeliveryResult` |
| `caps` | `hasCap`, `requireCap`, `canDo`, `isProductAdmin`, `CapabilityDeniedError` |
| `signature` | `buildSignedRequest`, `signPayload`, `safeEqual`, `isTimestampFresh` |
| `validate` | `assertWorkItem`, `assertEvent`, `partitionWorkItems`, `ContractViolationError` |
| `client` | `HubClient`, `buildSessionStartedEvent`, `buildCapabilityDeniedEvent` |

## Versioning

Additive changes (a new optional field) do not bump the major version. Removals
or semantic changes do. Every payload carries a `schema` field; Hub accepts `v1`
and returns `400` for anything else.
