/** Krontiva Hub — envelope types. Integration Contract v1. */

import type { WORK_ITEM_STATES, HORIZONS, CAP_LEVELS } from './constants.js'

export type WorkItemState = (typeof WORK_ITEM_STATES)[number]
export type Horizon = (typeof HORIZONS)[number]
export type CapLevel = (typeof CAP_LEVELS)[number]

/** `{product_id}:{level}` — e.g. 'pipee:write'. */
export type Capability = `${string}:${CapLevel}`

// ─── Identity ────────────────────────────────────────────────────────────────

/**
 * Claims in a Hub-issued RS256 token, verified against the JWKS endpoint.
 *
 * `role` is informational only. Authorize on `caps` — role-to-capability
 * mapping is Hub's business and changes without notice (contract §2.2).
 */
export interface HubClaims {
  iss: string
  /** Hub's stable user id. Store this as your foreign key to a person — never email, which changes. */
  sub: string
  email: string
  name: string | null
  role: string
  caps: Capability[]
  iat: number
  exp: number
}

/** What a product attaches to a request after verifying the token. */
export interface RequestContext {
  userId: string
  email: string
  caps: Capability[]
}

// ─── Events ──────────────────────────────────────────────────────────────────

/**
 * An engagement event. `action` is `{noun}.{verb}` in past tense; products may
 * define their own nouns.
 */
export interface HubEvent {
  schema?: 'hub.event.v1'
  product_id: string
  actor_id: string
  action: string
  object_type?: string | null
  object_id?: string | null
  /** ISO 8601. */
  occurred_at: string
  meta?: Record<string, unknown>
}

// ─── Work items ──────────────────────────────────────────────────────────────

/**
 * A work-item snapshot, upserted on `(product_id, external_id)`.
 *
 * Send on change, plus a full reconciliation set every 6 hours.
 */
export interface HubWorkItem {
  schema?: 'hub.work_item.v1'
  product_id: string
  /** Your primary key for this item, as a string. */
  external_id: string
  title: string
  state: WorkItemState
  /**
   * Required and non-null. An item without an owner cannot appear on a
   * per-person board, so resolve a default owner or do not send the item.
   */
  owner_id: string
  /**
   * Optional display name for owner_id, for products that haven't adopted
   * Hub's own user id as owner_id yet. Hub uses this to keep an admin-side
   * alias fresh so people see a name instead of a raw id — it never
   * overrides an actual Hub account match.
   */
  owner_name?: string | null
  horizon?: Horizon | null
  /** Required. The Monday View links every row back to source. */
  url: string
  opened_at: string
  /** Drives cycle time and "moved this week". */
  state_changed_at: string
  /** Set when state becomes 'blocked', cleared otherwise. */
  blocked_since?: string | null
  due_at?: string | null
  closed_at?: string | null
  meta?: Record<string, unknown>
}

// ─── Heartbeat ───────────────────────────────────────────────────────────────

/**
 * Sent every 15 minutes. Hub compares `work_item_counts` against its own and
 * alerts on drift — a worker delivering half its events is more dangerous than
 * one delivering none (contract §5).
 */
export interface HubHeartbeat {
  product_id: string
  sent_at: string
  work_item_counts: Partial<Record<WorkItemState, number>>
  outbox_pending: number
  outbox_oldest_pending_seconds?: number | null
}

// ─── Outbox ──────────────────────────────────────────────────────────────────

/**
 * Shape of a local outbox row. Products must not POST to Hub inline in a
 * request handler — write here in the same transaction as the domain write,
 * and let a worker drain it (contract §3.3). A Hub outage then costs
 * freshness, not data.
 */
export interface OutboxRow<T = HubEvent | HubWorkItem> {
  id: number | string
  payload: T
  created_at: string
  delivered_at: string | null
  attempts: number
  last_error: string | null
}

/** Which Hub endpoint an outbox row is destined for. */
export type OutboxTarget = 'events' | 'work-items'

// ─── Delivery results ────────────────────────────────────────────────────────

export interface DeliveryOk {
  ok: true
  status: number
  accepted?: number
}

export interface DeliveryError {
  ok: false
  status: number
  error: string
  /**
   * True when the failure is transient and the row should stay in the outbox:
   * network failure, 429, or 5xx. A 400 or 401 will never succeed on retry —
   * those need a fix, not a retry.
   */
  retryable: boolean
  retryAfterSeconds?: number
}

export type DeliveryResult = DeliveryOk | DeliveryError
