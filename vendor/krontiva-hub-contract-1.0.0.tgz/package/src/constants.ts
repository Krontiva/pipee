/** Krontiva Hub — shared constants. Integration Contract v1. */

export const HUB_ORIGIN = 'https://hub.krontiva.africa'

export const HUB_ENDPOINTS = {
  jwks: `${HUB_ORIGIN}/.well-known/jwks.json`,
  events: `${HUB_ORIGIN}/api/hub/events`,
  workItems: `${HUB_ORIGIN}/api/hub/work-items`,
  heartbeat: `${HUB_ORIGIN}/api/hub/heartbeat`,
} as const

/** Cookie Hub sets on the .krontiva.africa parent domain. */
export const SESSION_COOKIE = 'krontiva_session'

/** Signed-request headers. Casing is irrelevant; these are the canonical names. */
export const SIGNATURE_HEADERS = {
  product: 'X-Krontiva-Product',
  timestamp: 'X-Krontiva-Timestamp',
  signature: 'X-Krontiva-Signature',
} as const

export const SCHEMA_VERSIONS = {
  event: 'hub.event.v1',
  workItem: 'hub.work_item.v1',
} as const

export const WORK_ITEM_STATES = ['open', 'active', 'blocked', 'done', 'dropped'] as const
export const HORIZONS = ['now', 'next', 'later'] as const
export const CAP_LEVELS = ['read', 'write', 'admin'] as const

/** Verbs the contract defines. Products may define their own nouns. */
export const EVENT_VERBS = [
  'created',
  'updated',
  'deleted',
  'viewed',
  'published',
  'assigned',
  'state_changed',
] as const

/** Every product must emit these two, whatever else it sends. */
export const RESERVED_ACTIONS = {
  /** First authenticated request in a 30-minute window. */
  sessionStarted: 'session.started',
  /** Emitted alongside every 403, with meta.cap naming the denied capability. */
  capabilityDenied: 'capability_denied',
} as const

export const LIMITS = {
  /** Hub rejects batches larger than this. */
  eventsPerBatch: 100,
  /** Hub rejects timestamps outside this window, in seconds. */
  signatureSkewSeconds: 300,
  /** Token lifetime. Hub refreshes via the shared-domain cookie. */
  tokenTtlSeconds: 900,
  /** Send a heartbeat at least this often, in seconds. */
  heartbeatIntervalSeconds: 900,
  /** Hub alerts if no heartbeat arrives within this window, in seconds. */
  heartbeatStaleSeconds: 2700,
  /** Full reconciliation send interval, in seconds. */
  reconciliationIntervalSeconds: 21600,
  /** Hub alerts if the oldest undelivered outbox row exceeds this, in seconds. */
  outboxStaleSeconds: 900,
  /** Hub alerts if reported and stored counts differ by more than this. */
  countDriftThreshold: 2,
} as const
