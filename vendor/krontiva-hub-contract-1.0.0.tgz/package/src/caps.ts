/**
 * Capability resolution.
 *
 * Contract §2.3 says products resolve implication locally rather than expecting
 * Hub to expand the list. That means this rule is implemented once here — three
 * separate implementations of "admin implies write implies read" would diverge,
 * and the divergence would show up as a permissions bug nobody can reproduce.
 */

import type { Capability, RequestContext } from './types.js'

/**
 * Does this capability set satisfy `required`?
 *
 * `write` implies `read`; `admin` implies both. Pure — no I/O.
 *
 * ```ts
 * hasCap(['pipee:admin'], 'pipee:read')   // true
 * hasCap(['pipee:write'], 'pipee:admin')  // false
 * ```
 */
export function hasCap(caps: readonly string[], required: string): boolean {
  if (caps.includes(required)) return true

  const separator = required.lastIndexOf(':')
  if (separator < 1) return false

  const product = required.slice(0, separator)
  const level = required.slice(separator + 1)

  if (level === 'read') {
    return caps.includes(`${product}:write`) || caps.includes(`${product}:admin`)
  }
  if (level === 'write') {
    return caps.includes(`${product}:admin`)
  }
  return false
}

/** Thrown by `requireCap`. Catch it and return a 403. */
export class CapabilityDeniedError extends Error {
  readonly capability: string
  readonly userId: string

  constructor(capability: string, userId: string) {
    super(`Missing required capability: ${capability}`)
    this.name = 'CapabilityDeniedError'
    this.capability = capability
    this.userId = userId
  }
}

/**
 * Assert a capability or throw.
 *
 * On denial, return 403 **and** emit a `capability_denied` event — a denial is
 * a product signal, not just an error (contract §2.4). `buildCapabilityDeniedEvent`
 * shapes that event for you.
 */
export function requireCap(ctx: RequestContext, required: Capability | string): void {
  if (!hasCap(ctx.caps, required)) {
    throw new CapabilityDeniedError(required, ctx.userId)
  }
}

/** Non-throwing variant, for branching rather than gating. */
export function canDo(ctx: RequestContext, required: Capability | string): boolean {
  return hasCap(ctx.caps, required)
}

/**
 * True when the caller may act across the whole product rather than only on
 * rows they own. Use this to decide whether to apply owner scoping:
 *
 * ```ts
 * const q = db.from('opportunities').select()
 * if (!isProductAdmin(ctx, 'pipee')) q.eq('assigned_to', ctx.userId)
 * ```
 */
export function isProductAdmin(ctx: RequestContext, productId: string): boolean {
  return hasCap(ctx.caps, `${productId}:admin`)
}
