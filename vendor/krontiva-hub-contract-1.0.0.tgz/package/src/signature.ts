/**
 * Request signing for product → Hub pushes.
 *
 * Signature is HMAC-SHA256 over `timestamp + "." + raw_body`, hex-encoded and
 * prefixed `sha256=`. Three details make this easy to get subtly wrong, which
 * is why it lives here rather than in each product:
 *
 *   1. The timestamp is in **seconds**, not milliseconds.
 *   2. The separator is a literal `.` between timestamp and body.
 *   3. You must sign the **exact string you send**. Serialising twice can
 *      produce different key ordering, and the signature will not match.
 *
 * Uses Web Crypto only, so the same code runs on Node 18+, Deno, and Edge
 * runtimes. No dependencies.
 */

import { SIGNATURE_HEADERS, LIMITS } from './constants.js'

// Copied into an explicitly-allocated ArrayBuffer: TextEncoder returns a view
// over ArrayBufferLike, which TS 5.7+ will not accept as a BufferSource because
// it could in principle be a SharedArrayBuffer.
function bytes(input: string) {
  const encoded = new TextEncoder().encode(input)
  const out = new Uint8Array(new ArrayBuffer(encoded.byteLength))
  out.set(encoded)
  return out
}

function toHex(buffer: ArrayBuffer): string {
  return Array.from(new Uint8Array(buffer))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('')
}

/** Compute the signature for an already-serialised body. */
export async function signPayload(
  secret: string,
  timestampSeconds: number,
  rawBody: string,
): Promise<string> {
  const key = await crypto.subtle.importKey(
    'raw',
    bytes(secret),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign'],
  )
  const mac = await crypto.subtle.sign('HMAC', key, bytes(`${timestampSeconds}.${rawBody}`))
  return `sha256=${toHex(mac)}`
}

export interface SignedRequest {
  body: string
  headers: Record<string, string>
}

/**
 * Build the body and headers for a signed push. Send `result.body` verbatim —
 * re-serialising it will invalidate the signature.
 *
 * ```ts
 * const signed = await buildSignedRequest({ productId: 'pipee', secret, payload: events })
 * await fetch(HUB_ENDPOINTS.events, { method: 'POST', headers: signed.headers, body: signed.body })
 * ```
 */
export async function buildSignedRequest(params: {
  productId: string
  secret: string
  payload: unknown
  /** Override the clock. Only useful in tests. */
  timestampSeconds?: number
}): Promise<SignedRequest> {
  const timestamp = params.timestampSeconds ?? Math.floor(Date.now() / 1000)
  const body = JSON.stringify(params.payload)
  const signature = await signPayload(params.secret, timestamp, body)

  return {
    body,
    headers: {
      'Content-Type': 'application/json',
      [SIGNATURE_HEADERS.product]: params.productId,
      [SIGNATURE_HEADERS.timestamp]: String(timestamp),
      [SIGNATURE_HEADERS.signature]: signature,
    },
  }
}

/**
 * Constant-time comparison, so a verifier cannot be probed byte-by-byte via
 * timing. Only needed if you verify inbound signatures; Hub already does this
 * on its side.
 */
export function safeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false
  let diff = 0
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i)
  return diff === 0
}

/** Is this timestamp inside Hub's accepted window? */
export function isTimestampFresh(timestampSeconds: number, nowSeconds?: number): boolean {
  const now = nowSeconds ?? Math.floor(Date.now() / 1000)
  return Math.abs(now - timestampSeconds) <= LIMITS.signatureSkewSeconds
}
