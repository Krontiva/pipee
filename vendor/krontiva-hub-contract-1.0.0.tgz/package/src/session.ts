/**
 * Verification of Hub's shared session cookie (contract §1 — single
 * sign-on). Hub signs an RS256 JWT on login and sets it as `krontiva_session`
 * on the `.krontiva.africa` parent domain, so every `*.krontiva.africa`
 * product receives it automatically. This is the other half of that: given
 * the cookie value, prove it really came from Hub and hasn't expired,
 * without ever trusting it unverified.
 *
 * Web Crypto only, matching the rest of this package — no JWT library
 * dependency, so this runs in Node 18+, Deno, and Edge runtimes alike.
 */

import { HUB_ENDPOINTS, HUB_ORIGIN } from './constants.js'
import type { HubClaims } from './types.js'

export class HubSessionError extends Error {
  constructor(message: string) {
    super(message)
    this.name = 'HubSessionError'
  }
}

function bytes(input: string): Uint8Array<ArrayBuffer> {
  const encoded = new TextEncoder().encode(input)
  const out = new Uint8Array(new ArrayBuffer(encoded.byteLength))
  out.set(encoded)
  return out
}

// Same explicitly-allocated-ArrayBuffer copy as signature.ts's bytes(): a
// freshly-constructed Uint8Array's buffer could in principle be typed as a
// SharedArrayBuffer, which TS 5.7+ rejects as a Web Crypto BufferSource.
function base64UrlToBytes(b64url: string): Uint8Array<ArrayBuffer> {
  const b64 = b64url.replace(/-/g, '+').replace(/_/g, '/')
  const padded = b64 + '='.repeat((4 - (b64.length % 4)) % 4)
  const binary = atob(padded)
  const out = new Uint8Array(new ArrayBuffer(binary.length))
  for (let i = 0; i < binary.length; i++) out[i] = binary.charCodeAt(i)
  return out
}

function decodeJsonPart(part: string): Record<string, unknown> {
  return JSON.parse(new TextDecoder().decode(base64UrlToBytes(part)))
}

interface Jwk {
  kid?: string
  kty: string
  [key: string]: unknown
}

// Module-level cache — one fetch serves every verification until the cache
// expires, rather than hitting Hub's JWKS endpoint on every request. Matches
// the 1-hour Cache-Control Hub itself sets on that response.
let _jwksCache: { keys: Jwk[]; fetchedAt: number } | null = null
const JWKS_TTL_MS = 60 * 60 * 1000

async function getJwks(jwksUrl: string, fetchImpl: typeof fetch): Promise<Jwk[]> {
  const now = Date.now()
  if (_jwksCache && now - _jwksCache.fetchedAt < JWKS_TTL_MS) return _jwksCache.keys

  const res = await fetchImpl(jwksUrl)
  if (!res.ok) throw new HubSessionError(`Failed to fetch Hub's JWKS: ${res.status}`)
  const json = (await res.json()) as { keys?: Jwk[] }
  const keys = json.keys ?? []
  _jwksCache = { keys, fetchedAt: now }
  return keys
}

async function importVerifyKey(jwk: Jwk): Promise<CryptoKey> {
  return crypto.subtle.importKey(
    'jwk',
    jwk as unknown as JsonWebKey,
    { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' },
    false,
    ['verify'],
  )
}

export interface VerifyHubSessionOptions {
  /** Override for local testing against a Hub dev server. */
  jwksUrl?: string
  issuer?: string
  fetchImpl?: typeof fetch
  /** Override the clock. Only useful in tests. */
  nowSeconds?: number
}

/**
 * Verify a `krontiva_session` cookie value and return its claims.
 *
 * Throws `HubSessionError` for anything that would let a forged or expired
 * token through: bad structure, unknown key id, signature mismatch, wrong
 * issuer, or an expired `exp`. Never returns claims from a token that
 * failed any of those checks — there is no partial-trust path here.
 */
export async function verifyHubSession(
  token: string,
  opts: VerifyHubSessionOptions = {},
): Promise<HubClaims> {
  const jwksUrl = opts.jwksUrl ?? HUB_ENDPOINTS.jwks
  const issuer = opts.issuer ?? HUB_ORIGIN
  const fetchImpl = opts.fetchImpl ?? fetch
  const now = opts.nowSeconds ?? Math.floor(Date.now() / 1000)

  const parts = token.split('.')
  if (parts.length !== 3) throw new HubSessionError('Malformed token')
  // Non-null: the length check above guarantees all three exist.
  const headerB64 = parts[0]!
  const payloadB64 = parts[1]!
  const signatureB64 = parts[2]!

  let header: { alg?: string; kid?: string }
  let payload: HubClaims
  try {
    header = decodeJsonPart(headerB64) as { alg?: string; kid?: string }
    payload = decodeJsonPart(payloadB64) as unknown as HubClaims
  } catch {
    throw new HubSessionError('Malformed token')
  }

  if (header.alg !== 'RS256') throw new HubSessionError(`Unsupported algorithm: ${header.alg}`)
  if (!header.kid) throw new HubSessionError('Token has no key id')

  let keys = await getJwks(jwksUrl, fetchImpl)
  let jwk = keys.find(k => k.kid === header.kid)
  if (!jwk) {
    // Hub rotated its key since our last fetch — one forced refresh before
    // giving up, rather than rejecting a token signed with a genuinely new key.
    _jwksCache = null
    keys = await getJwks(jwksUrl, fetchImpl)
    jwk = keys.find(k => k.kid === header.kid)
  }
  if (!jwk) throw new HubSessionError(`No matching key for kid '${header.kid}'`)

  const key = await importVerifyKey(jwk)
  const signature = base64UrlToBytes(signatureB64)
  const signedData = bytes(`${headerB64}.${payloadB64}`)
  const valid = await crypto.subtle.verify('RSASSA-PKCS1-v1_5', key, signature, signedData)
  if (!valid) throw new HubSessionError('Signature verification failed')

  if (payload.iss !== issuer) {
    throw new HubSessionError(`Unexpected issuer: ${payload.iss}`)
  }
  if (typeof payload.exp !== 'number' || payload.exp <= now) {
    throw new HubSessionError('Token expired')
  }
  if (!payload.sub || !payload.email) {
    throw new HubSessionError('Token missing required claims')
  }

  return payload
}
