/**
 * Local validation.
 *
 * Hub rejects malformed payloads with a 400, which is unhelpful from inside an
 * outbox drain worker: the row is not retryable, so it sits there failing
 * silently. Validating at the emit site turns that into a loud error next to
 * the code that built the payload.
 *
 * These check the three things Hub is strict about — non-null owner, valid
 * state, present url — plus the mistakes that are easy to make with dates.
 */

import { WORK_ITEM_STATES, HORIZONS } from './constants.js'
import type { HubEvent, HubWorkItem, WorkItemState, Horizon } from './types.js'

export class ContractViolationError extends Error {
  readonly field: string
  readonly value: unknown

  constructor(field: string, message: string, value?: unknown) {
    super(`${field}: ${message}`)
    this.name = 'ContractViolationError'
    this.field = field
    this.value = value
  }
}

function requireIsoDate(field: string, value: unknown, required: boolean): void {
  if (value == null) {
    if (required) throw new ContractViolationError(field, 'is required')
    return
  }
  if (typeof value !== 'string' || Number.isNaN(Date.parse(value))) {
    throw new ContractViolationError(field, 'must be an ISO 8601 date string', value)
  }
}

function requireNonEmptyString(field: string, value: unknown): void {
  if (typeof value !== 'string' || value.trim() === '') {
    throw new ContractViolationError(field, 'must be a non-empty string', value)
  }
}

export function isWorkItemState(v: unknown): v is WorkItemState {
  return typeof v === 'string' && (WORK_ITEM_STATES as readonly string[]).includes(v)
}

export function isHorizon(v: unknown): v is Horizon {
  return typeof v === 'string' && (HORIZONS as readonly string[]).includes(v)
}

/** Throws `ContractViolationError` if this item would be rejected by Hub. */
export function assertWorkItem(item: HubWorkItem): void {
  requireNonEmptyString('external_id', item.external_id)
  requireNonEmptyString('title', item.title)

  // The field most often wrong. An item without an owner cannot appear on a
  // per-person board, so Hub refuses the whole batch.
  requireNonEmptyString('owner_id', item.owner_id)

  // Required because the Monday View links every row back to source.
  requireNonEmptyString('url', item.url)

  if (!isWorkItemState(item.state)) {
    throw new ContractViolationError(
      'state',
      `must be one of ${WORK_ITEM_STATES.join(' | ')}`,
      item.state,
    )
  }

  if (item.horizon != null && !isHorizon(item.horizon)) {
    throw new ContractViolationError('horizon', `must be one of ${HORIZONS.join(' | ')} or null`, item.horizon)
  }

  requireIsoDate('opened_at', item.opened_at, true)
  requireIsoDate('state_changed_at', item.state_changed_at, true)
  requireIsoDate('blocked_since', item.blocked_since, false)
  requireIsoDate('due_at', item.due_at, false)
  requireIsoDate('closed_at', item.closed_at, false)

  // blocked_since is set when state becomes 'blocked', cleared otherwise.
  // Getting this wrong makes the blocked-and-aging section silently wrong
  // rather than visibly broken, so it is worth catching here.
  if (item.state === 'blocked' && !item.blocked_since) {
    throw new ContractViolationError('blocked_since', "is required when state is 'blocked'")
  }
  if (item.state !== 'blocked' && item.blocked_since) {
    throw new ContractViolationError('blocked_since', "must be null unless state is 'blocked'", item.blocked_since)
  }
}

/** Throws `ContractViolationError` if this event would be rejected by Hub. */
export function assertEvent(event: HubEvent): void {
  requireNonEmptyString('actor_id', event.actor_id)
  requireNonEmptyString('action', event.action)
  requireIsoDate('occurred_at', event.occurred_at, true)

  // {noun}.{verb}, past tense. Not enforced by Hub, but a typo here produces a
  // silently separate action name that never shows up where you expect.
  if (!/^[a-z0-9_]+(\.[a-z0-9_]+)+$/.test(event.action)) {
    throw new ContractViolationError(
      'action',
      "must be lowercase {noun}.{verb}, e.g. 'opportunity.created'",
      event.action,
    )
  }
}

/**
 * Filter a batch into deliverable and rejected, instead of throwing on the
 * first bad row. Useful for a reconciliation send, where one unowned item
 * should not block the other several hundred.
 */
export function partitionWorkItems(items: HubWorkItem[]): {
  valid: HubWorkItem[]
  invalid: Array<{ item: HubWorkItem; reason: string }>
} {
  const valid: HubWorkItem[] = []
  const invalid: Array<{ item: HubWorkItem; reason: string }> = []

  for (const item of items) {
    try {
      assertWorkItem(item)
      valid.push(item)
    } catch (e) {
      invalid.push({ item, reason: e instanceof Error ? e.message : String(e) })
    }
  }
  return { valid, invalid }
}
