/**
 * Thin delivery client for product → Hub pushes.
 *
 * Deliberately does not retry: retries belong in your outbox drain worker,
 * which owns the backoff state. This classifies failures as retryable or not
 * so the worker knows whether to leave the row for another pass.
 */

import { HUB_ENDPOINTS, LIMITS, SCHEMA_VERSIONS, RESERVED_ACTIONS } from './constants.js'
import { buildSignedRequest } from './signature.js'
import { assertWorkItem, assertEvent } from './validate.js'
import type {
  HubEvent,
  HubWorkItem,
  HubHeartbeat,
  DeliveryResult,
  RequestContext,
} from './types.js'

interface Endpoints {
  jwks: string
  events: string
  workItems: string
  heartbeat: string
}

export interface HubClientOptions {
  productId: string
  /** The product's own HMAC secret. Server-side only — never ship this to a browser. */
  secret: string
  /** Override for local testing against a Hub dev server. */
  origin?: string
  fetchImpl?: typeof fetch
}

export class HubClient {
  private readonly productId: string
  private readonly secret: string
  private readonly endpoints: Endpoints
  private readonly doFetch: typeof fetch

  constructor(opts: HubClientOptions) {
    if (!opts.productId) throw new Error('HubClient: productId is required')
    if (!opts.secret) throw new Error('HubClient: secret is required')

    this.productId = opts.productId
    this.secret = opts.secret
    this.doFetch = opts.fetchImpl ?? fetch
    this.endpoints = opts.origin
      ? {
          jwks: `${opts.origin}/.well-known/jwks.json`,
          events: `${opts.origin}/api/hub/events`,
          workItems: `${opts.origin}/api/hub/work-items`,
          heartbeat: `${opts.origin}/api/hub/heartbeat`,
        }
      : HUB_ENDPOINTS
  }

  /** Deliver a batch of events. Hub caps a batch at 100. */
  async sendEvents(events: HubEvent[]): Promise<DeliveryResult> {
    if (events.length === 0) return { ok: true, status: 200, accepted: 0 }
    if (events.length > LIMITS.eventsPerBatch) {
      return {
        ok: false,
        status: 400,
        error: `Batch of ${events.length} exceeds the limit of ${LIMITS.eventsPerBatch}`,
        retryable: false,
      }
    }
    // product_id is stamped after the spread so the client's own id always
    // wins — a caller must not be able to attribute events to another product.
    const stamped = events.map(e => ({
      schema: SCHEMA_VERSIONS.event,
      ...e,
      product_id: this.productId,
    }))
    stamped.forEach(assertEvent)
    return this.post(this.endpoints.events, stamped)
  }

  /** Upsert work items, keyed on (product_id, external_id). */
  async sendWorkItems(items: HubWorkItem[]): Promise<DeliveryResult> {
    if (items.length === 0) return { ok: true, status: 200, accepted: 0 }
    const stamped = items.map(i => ({
      schema: SCHEMA_VERSIONS.workItem,
      ...i,
      product_id: this.productId,
    }))
    stamped.forEach(assertWorkItem)
    return this.post(this.endpoints.workItems, stamped)
  }

  async sendHeartbeat(beat: Omit<HubHeartbeat, 'product_id'>): Promise<DeliveryResult> {
    return this.post(this.endpoints.heartbeat, { product_id: this.productId, ...beat })
  }

  private async post(url: string, payload: unknown): Promise<DeliveryResult> {
    let signed
    try {
      signed = await buildSignedRequest({ productId: this.productId, secret: this.secret, payload })
    } catch (e) {
      return { ok: false, status: 0, error: `Failed to sign request: ${String(e)}`, retryable: false }
    }

    let res: Response
    try {
      res = await this.doFetch(url, { method: 'POST', headers: signed.headers, body: signed.body })
    } catch (e) {
      // Network-level failure — always worth another pass.
      return { ok: false, status: 0, error: `Network error: ${String(e)}`, retryable: true }
    }

    if (res.ok) {
      const json = (await res.json().catch(() => ({}))) as { accepted?: number }
      return { ok: true, status: res.status, accepted: json.accepted }
    }

    const detail = await res.text().catch(() => '')
    const retryAfter = Number(res.headers.get('retry-after') ?? '')

    return {
      ok: false,
      status: res.status,
      error: detail || `Hub returned ${res.status}`,
      // 400 (malformed) and 401 (bad signature) will never succeed on retry —
      // they need a fix. 429 and 5xx will.
      retryable: res.status === 429 || res.status >= 500,
      ...(Number.isFinite(retryAfter) ? { retryAfterSeconds: retryAfter } : {}),
    }
  }
}

// ─── Event builders for the two reserved actions ─────────────────────────────

/** Emit on the first authenticated request in a 30-minute window. */
export function buildSessionStartedEvent(productId: string, actorId: string): HubEvent {
  return {
    schema: SCHEMA_VERSIONS.event,
    product_id: productId,
    actor_id: actorId,
    action: RESERVED_ACTIONS.sessionStarted,
    occurred_at: new Date().toISOString(),
    meta: {},
  }
}

/**
 * Emit alongside every 403. Pair this with `requireCap` — catch
 * `CapabilityDeniedError`, write this event to your outbox, and return 403.
 */
export function buildCapabilityDeniedEvent(
  productId: string,
  ctx: Pick<RequestContext, 'userId'>,
  capability: string,
  extra?: Record<string, unknown>,
): HubEvent {
  return {
    schema: SCHEMA_VERSIONS.event,
    product_id: productId,
    actor_id: ctx.userId,
    action: RESERVED_ACTIONS.capabilityDenied,
    occurred_at: new Date().toISOString(),
    meta: { cap: capability, ...extra },
  }
}
